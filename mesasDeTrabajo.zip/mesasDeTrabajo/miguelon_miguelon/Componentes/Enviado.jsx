import React from 'react'

const Enviado = ({nombre, edad, pokemonFavorito}) => {
  return (
    <div>
        <h3>Nombre:  {nombre}, Edad: {edad}, Pokemón favorito: {pokemonFavorito}</h3>
        <h4>Bienvenido {nombre}</h4>
    </div>
  )
}

export default Enviado