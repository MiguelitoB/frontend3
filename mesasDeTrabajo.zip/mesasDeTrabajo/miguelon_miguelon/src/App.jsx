import { useState } from 'react'
import './App.css'
import Enviado from '../Componentes/Enviado';

function App() {
  const [nombre, setNombre] = useState("")
  const [edad, setEdad] = useState("");
  const [pokemonFavorito, setPokemonFavorito] = useState("")

  const onChangeNombre=(e)=>setNombre(e.target.value)
  const onChangeEdad=(e)=>setEdad(e.target.value);
  const onChangePokemonFavorito=(e)=>setPokemonFavorito(e.target.value)

  const onSubmitForm = (e) =>{
    e.preventDefault()
  }

  const [show, setShow] = useState(false)
    const [error, setError] = useState(false)

    const handleSubmit = (event) => {
        event.preventDefault()
        if(nombre.length > 3 && edad.includes(' ') && pokemonFavorito.length>4){
            setShow(true)
            setError(false)
        } else {
            setError(true)
        }
    }
    console.log(nombre)
    console.log(edad);
    console.log(pokemonFavorito);

  return (
    <>
      <div>
        <h3>Registro</h3>
      {!show &&
        <form onSubmit={handleSubmit}>
        <input type="text" placeholder='Nombre del usuario'
        value={nombre} 
        onChange={onChangeNombre}/>

<input type="text" placeholder='Edad'
        value={edad} 
        onChange={onChangeEdad}/>

<input type="text" placeholder='Pokemón favorito'
        value={pokemonFavorito} 
        onChange={onChangePokemonFavorito}/>

        <button type="submit">Enviar</button>

        </form>
}
{
  show?
  <Enviado nombre={nombre} edad={edad} pokemonFavorito={pokemonFavorito}/>
  :
  null
}
{error && <h5 style={{color: 'red'}}>Por favor, diligencia bien tus datos</h5>}
      </div>
    </>
  )
}

export default App
